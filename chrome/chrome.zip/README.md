# LookingGlassTTV
Extension for twitch.tv clips that allows you to see the clip from other perspectives. Work in progress.
